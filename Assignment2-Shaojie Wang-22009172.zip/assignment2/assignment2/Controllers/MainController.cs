﻿using MvcApplication1.common;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;

namespace assignment2.Controllers
{
    public class MainController : Controller
    {
        // GET: Main
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult generic()
        {
            return View();
        }
        public ActionResult elements()
        {
            return View();
        }
        [HttpPost]
        public ActionResult getTableDates(string name)
        {
            string sql = "";
            if (name == null || name == "all")
            {
                sql = @"SELECT TOP (1000) [id]
                 ,[name]
                 ,[gender]
                 ,[age]
                FROM [assignment2].[dbo].[customer]";
            }
            else
            {
                sql = @"SELECT TOP (1000) [id]
                 ,[name]
                 ,[gender]
                 ,[age]
                FROM [assignment2].[dbo].[customer] where name like '%" + name + "%'";
            }

            DataTable dt = SqlHelper.getdata(sql);
            if (dt != null)
            {
                JavaScriptSerializer javaScriptSerializer = new JavaScriptSerializer();
                javaScriptSerializer.MaxJsonLength = Int32.MaxValue; //取得最大数值
                ArrayList arrayList = new ArrayList();
                foreach (DataRow dataRow in dt.Rows)
                {
                    Dictionary<string, object> dictionary = new Dictionary<string, object>(); //实例化一个参数集合
                    foreach (DataColumn dataColumn in dt.Columns)
                    {
                        dictionary.Add(dataColumn.ColumnName, dataRow[dataColumn.ColumnName].ToString().Trim());
                    }
                    arrayList.Add(dictionary); //ArrayList集合中添加键值
                }
                return Json(arrayList, JsonRequestBehavior.AllowGet); //返回一个json字符串
            }

            return Json("查询失败");
        }
    }
}