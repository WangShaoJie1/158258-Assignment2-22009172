﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace MvcApplication1.common
{
    public class SqlHelper
    {
        public static string constr = "DESKTOP-F7DGJSR\\SQLEXPRESS ;initial catalog=assignment2;user id = ;password = ";

        public static DataTable getdata(string sql)
        {
            SqlConnection con = new SqlConnection(constr);
            SqlCommand commond = new SqlCommand(sql, con);
            SqlDataAdapter oda = new SqlDataAdapter(commond);
            DataTable dt = new DataTable();
            try
            {
                con.Open();
                oda.Fill(dt);
                return dt;
            }
            catch (Exception e)
            {
                return null;
            }
            finally
            {
                dt.Dispose();
                oda.Dispose();
                commond.Dispose();
                con.Close();
                con.Dispose();
            }
        }
    }
}